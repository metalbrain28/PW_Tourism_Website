
This application requires nodejs (v > 8.0)

After clone, run "npm install".
