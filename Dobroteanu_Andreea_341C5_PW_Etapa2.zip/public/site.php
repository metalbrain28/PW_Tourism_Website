<?php
/**
 * User: Andreea Dobroteanu
 * Date: 11.04.2018
 * Time: 23:30
 */

session_start();

include("../templates/site_start.html");
include("../templates/index.html");
include("../templates/partials/book_trip.html");
include("../templates/partials/login_form.html");
include("../templates/partials/conversation.html");
include("../templates/partials/all_conversations.html");
include("../templates/site_end.html");
